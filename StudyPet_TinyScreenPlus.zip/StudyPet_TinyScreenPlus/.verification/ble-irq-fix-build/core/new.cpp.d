C:\Users\raiso\Downloads\StudyPet_TinyScreenPlus_updated_capybara\StudyPet_TinyScreenPlus\.verification\ble-irq-fix-build\core\new.cpp.o: \
 C:\Users\raiso\AppData\Local\Arduino15\packages\TinyCircuits\hardware\samd\1.1.0\cores\arduino\new.cpp
