C:\Users\raiso\Downloads\StudyPet_TinyScreenPlus_updated_capybara\StudyPet_TinyScreenPlus\.verification\hardware-check-build\core\abi.cpp.o: \
 C:\Users\raiso\AppData\Local\Arduino15\packages\TinyCircuits\hardware\samd\1.1.0\cores\arduino\abi.cpp
