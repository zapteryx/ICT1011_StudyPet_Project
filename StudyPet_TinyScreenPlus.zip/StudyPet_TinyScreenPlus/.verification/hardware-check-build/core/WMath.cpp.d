C:\Users\raiso\Downloads\StudyPet_TinyScreenPlus_updated_capybara\StudyPet_TinyScreenPlus\.verification\hardware-check-build\core\WMath.cpp.o: \
 C:\Users\raiso\AppData\Local\Arduino15\packages\TinyCircuits\hardware\samd\1.1.0\cores\arduino\WMath.cpp \
 C:\Users\raiso\AppData\Local\Arduino15\packages\TinyCircuits\hardware\samd\1.1.0\cores\arduino\WMath.h
