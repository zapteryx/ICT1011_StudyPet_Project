C:\Users\raiso\Downloads\StudyPet_TinyScreenPlus_updated_capybara\StudyPet_TinyScreenPlus\.verification\ble-final-build\core\avr\dtostrf.c.o: \
 C:\Users\raiso\AppData\Local\Arduino15\packages\TinyCircuits\hardware\samd\1.1.0\cores\arduino\avr\dtostrf.c
