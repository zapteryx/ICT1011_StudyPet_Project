bluenrg_IFR.o: \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\bluenrg_IFR.c \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\hal.h \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\hal_types.h \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\ble_status.h \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\bluenrg_updater_aci.h \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\compiler.h \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\bluenrg_utils.h
