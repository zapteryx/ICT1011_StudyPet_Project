osal.o: \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\osal.c \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\osal.h \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\hal_types.h \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\hal.h \
 c:\Users\raiso\OneDrive\Documents\Arduino\libraries\STBLE\src\STBlueNRG\ble_status.h
