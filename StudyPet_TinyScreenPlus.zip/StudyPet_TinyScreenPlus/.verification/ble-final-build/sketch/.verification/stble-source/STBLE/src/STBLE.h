#line 1 "C:\\Users\\raiso\\Downloads\\StudyPet_TinyScreenPlus_updated_capybara\\StudyPet_TinyScreenPlus\\.verification\\stble-source\\STBLE\\src\\STBLE.h"
#include "arduino_bluenrg_ble.h"
#include "arduino_hal.h"

#ifdef __cplusplus
 extern "C" {
#endif
	#include "STBlueNRG/bluenrg_utils.h"
	#include "STBlueNRG/hal_types.h"
	#include "STBlueNRG/ble_status.h"
	#include "STBlueNRG/hci.h"
	#include "STBlueNRG/hci_le.h"
	#include "STBlueNRG/bluenrg_aci.h"
	#include "STBlueNRG/gp_timer.h"
	#include "STBlueNRG/bluenrg_gap.h"
	#include "STBlueNRG/sm.h"
#ifdef __cplusplus
}
#endif
